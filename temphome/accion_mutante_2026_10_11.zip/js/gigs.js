import { gigs } from "../data/gig_data.js";

const dateOptions = {
  weekday: "long",
  year: "numeric",
  month: "long",
  day: "numeric",
};

export const singleGig = (gig) => {
  const currentGig = document.createElement("div");
  currentGig.classList.add("gig");
  currentGig.innerHTML = `<h2 class="title">${gig.title}</h2>
    <img src="images/gigs/${gig.image}" alt="${gig.title}" class="image">
    <h3 class="location">${gig.location}</h3>
    <p class="address">
      ${gig.address.map((addr) => '<span class="address-line">' + addr + '</span>').join("")}
    </p>
    <h3 class="date">${new Date(gig.date).toLocaleDateString("en-US", dateOptions)}</h3>
    <table class="time">
      <tr>
        <td>Doors open</td>
        <td>${gig.timeDoorsOpen}</td>
      </tr>
      <tr>
        <td>Start</td>
        <td>${gig.timeStart}</td>
      </tr>
    </table>`;
  if (gig.description) {
    currentGig.innerHTML += `<p class="description">${gig.description}</p>`;
  }
  if (gig.link) {
    currentGig.innerHTML += `<a href="${gig.link}" class="link" target="_blank" rel="noopener noreferrer"></a>`;
  }
  return currentGig;
}

class GigsSection extends HTMLElement {
  connectedCallback() {
    this.innerHTML = `<h1 class="sectionTitle">Upcoming Gigs<div id="giganchor"></div></h1>`;

    gigs.sort((a, b) => new Date(a.date) - new Date(b.date)).filter((gig) => new Date(gig.date) >= new Date()).forEach((gig) => {
      this.appendChild(singleGig(gig));
    });
  }
}
customElements.define("gigs-section", GigsSection);